# forgetme
Learn how to make Git ignore files that are already comitted/tracked.
